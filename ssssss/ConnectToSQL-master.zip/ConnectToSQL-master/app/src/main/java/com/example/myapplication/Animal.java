package com.example.myapplication;

public class Animal {
    String name,kind,age;

    public Animal(String name,String kind,String age){
        this.name = name;
        this.kind = kind;
        this.age = age;
    }
}
